package org.example.mybookmarks.model;

public class ResourceNotFoundException extends ModelException {

    public ResourceNotFoundException(String message) {
        super(message);
    }

}
