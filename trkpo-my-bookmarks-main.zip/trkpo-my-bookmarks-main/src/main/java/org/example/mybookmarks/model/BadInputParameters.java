package org.example.mybookmarks.model;

public class BadInputParameters extends ModelException {

    public BadInputParameters(String message) {
        super(message);
    }

}
