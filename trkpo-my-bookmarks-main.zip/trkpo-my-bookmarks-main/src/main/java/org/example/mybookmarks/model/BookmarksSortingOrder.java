package org.example.mybookmarks.model;

public enum BookmarksSortingOrder {
    BY_DATE,
    BY_TITLE,
    BY_URL
}
