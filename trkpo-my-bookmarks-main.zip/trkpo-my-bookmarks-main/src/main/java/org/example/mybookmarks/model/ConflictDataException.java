package org.example.mybookmarks.model;


public class ConflictDataException extends ModelException {

    public ConflictDataException(String message, Throwable cause) {
        super(message, cause);
    }

}
